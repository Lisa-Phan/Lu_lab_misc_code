#!/bin/bash

#SBATCH -p normal
#SBATCH -J cutadapt
#SBATCH -e %x.err
#SBATCH -o %x.out
#SBATCH -n 8
#SBATCH -N 1
#SBATCH -t 02:00:00

source ./params.sh

echo Step 0: Define variables, tools, primer_sequences and paths at echo `date`.
JOB_NAME=`tail -n 1 .userlog.txt | cut -d" " -f4`
REP_OPT=`tail -n 1 .userlog.txt | cut -d" " -f6`


## Input Directory for sequences to be processed
INPUT=$JOB_NAME/step2_assembly/merged

## Directory for sequences that have been cut
OUTDIR=$JOB_NAME/step3_cutadapt

# Extension input
input_ext=.merged.fastq

files=($INPUT/*$input_ext)

fastqcmod=fastqc
fastxmod=fastx_toolkit

all_dir=($OUTDIR $OUTDIR/fastqc)


## These needs to be provided as inputs by users

## Forward primer of selection (or 5' adapter of sequencing)
fwdprimer=$(get_var FORWARD)
## Reverse primer of selection (or 3' adapter of sequencing) in "forward" direction, 5'-3' as you would order from IDT
revprimer=$(get_var REVERSE)

## Maximum error rate for adapters (e.g. 0.1 for fivepadapt of 10nts = 1nt mismatch allowed, it should be percentage. Details could be found in the website of the pipline)
error=$(get_var ERROR)
## Minimum length of sequences (sequences below this # of nt are discarded)
minlength=$(get_var MINLENGTH)
## Maximum length of sequences (sequences above this # of nt are discarded, for the synthetic pools, it will be the size of the random regions. Such as 48 min and 52 max for the N50 pool)
maxlength=$(get_var MAXLENGTH)

echo Step 1: Check and create directories at `date`.

## Only runs if $all_dir is uncommented above and has something added to it. Otherwise, will create $count_dir and $clust_dir separately later in the script when the "count" or "clust" programs are run.
if [ ! -z $all_dir ]; then
  for d in ${all_dir[@]}; do  ## Loops through all directories listed in array $all_dir
  ## If the directory doesn't exist, creates the directory (and all parent directories).
    if [ ! -d $d ]; then
      mkdir -p $d
      echo Creating directory $d and any parent directories at `date`.
    fi
  done
fi

echo STEP2: load module, define input files.

module load biocontainers
module load cutadapt

fivepadapt1=$fwdprimer
fivepadapt2=$revprimer
threepadapt1=$( echo $fivepadapt2 | tr ACGTacgt TGCAtgca | rev )

COUNTER=1

#create file


#if [ ! -z $INPUT/file_list ]; then
#   	 ls $INPUT/*$input_ext > $INPUT/file_list  ## Updates the file_list file
#   	 echo Created an updated file_list in $INPUT at `date`.
#    else
#    sleep 0.1                                          ## Sleep for 0.1 second if not the first task
#fi


file_list=$INPUT/file_list
ls $INPUT/*$input_ext > $file_list
echo 'Temp file list created at `date`'

echo `wc -l < $file_list`
line_count=`wc -l < $file_list`
echo Line_number $line_count
max_file_number=$line_count
echo max sample number $max_file_number


while [ $COUNTER -le $max_file_number ]
do
echo sample $COUNTER

	A=`echo "$COUNTER"p`

	echo extracting from line number $A
	R=`sed -n "$A" $file_list`   ## Gets the filename from the $file_list file corresponding to the current $task_id

	echo Grabbing filenames from the external file $file_list at `date`.

input_file=`basename $R $input_ext`          ## Removes the directory from the filename to get the basename
sample_name=${input_file%%$input_ext}        ## Remove the input_ext from the filename

## Output of variables to help with troubleshooting
echo -e "Variable R is $R"
echo -e "Variable sample_name is $sample_name."
echo -e "Variable input_file is $input_file."

echo STEP2: Remove Illumina universal adapter sequences at 'date'.
ADAPTOR=$(get_var ADAPTOR)
CORE=$(get_var CORE)

cutadapt -j $CORE -a $ADAPTOR -e $error --discard-trimmed -o $OUTDIR/$sample_name.T1.fastq $R
cutadapt -j $CORE -b file:shorter_complex.fasta -n 4 --discard-trimmed -e 0.2 -o $OUTDIR/$sample_name.T2.fastq $OUTDIR/$sample_name.T1.fastq
echo STEP3: Remove adapter sequences and remain sequence with correct size at 'date'.
cutadapt -j $CORE -a $fivepadapt1...$threepadapt1 -e $error -m $minlength -M $maxlength --discard-untrimmed -o $OUTDIR/$sample_name.Trim.fastq $OUTDIR/$sample_name.T2.fastq
exitcode=$?
 if [ $exitcode -ne 0 ]
 then
    echo The cutadapt program stopped at sample=${samplename}, with Error Code=$exitcode
    exit $exitcode
 fi
echo Finished trimming $samplename in $OUTDIR at `date`

echo STEP4: FastQC of the merged files to assess quality of selection pool sequences at `date`.
module load $fastqcmod

fastqc -t $CORE -o $OUTDIR/fastqc $OUTDIR/$sample_name.Trim.fastq

echo Finished processing $R at `date`.

printf "The value of COUNTER=%d\n" $COUNTER
let COUNTER=COUNTER+1
printf "The new value of COUNTER=%d\n" $COUNTER

done

echo Finished processing at `date`.

module purge

