#!/bin/bash

#Please do not introduce additional spacing between variable name and variable 
#Optional but useful Parameters

get_var () { grep "$1" params.sh | cut -d"=" -f2 ; } 

#User Email
EMAIL=dhp563@my.utexas.edu

##----------------------- Params for step 3 ---------------------##
#Forward primer sequence
FORWARD=GAACGCCAGCACATGGAC

#Reverse primer sequence
REVERSE=CCTTATGCAGTTGCTCTCC

#Values for error, minlength, and  maxlength
#Error threshold for cutadapt filtering
#min and max length is the range for selected aptamer sequence

ERROR=0.1
MINLENGTH=0
MAXLENGTH=999999999

#Illumina universal adaptor
ADAPTOR=AGATCGGAAGAG

#Number of threads for cutadapt and fastqc
CORE=80

##--------------- Params for FASTaptamer step 4 ------------------ ##
#Cluster or count file enrichment, 'clust' or 'count'
ENRICH=clust

#Auto enrich or manual enrich
SCRIPT_MODE=manual

PROGRAM=both
 ## either both, clust, or count
DISTANCE=7
FILTER_CONDITION=8001
MAX_CLUSTER=0 
 ## set to 0 for max number of clusters

